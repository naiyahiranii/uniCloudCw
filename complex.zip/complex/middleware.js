const express = require('express'); 
const session = require('express-session'); 
const bodyParser = require('body-parser'); 
const sql = require('mssql'); 
const sendEmail = require('./sendMail'); 
const bcrypt = require('bcryptjs'); 
const dotenv = require('dotenv'); 
const path = require('path'); 

dotenv.config();  // Load environment variables from .env file

const app = express();  // Initialize Express app
const port = 1433;  // Set port for the server

// SQL Server Connection Configuration
const connection = {
    host: '54.204.188.80',
    user: process.env.DB_USER,  // MSSQL database username
    password: process.env.DB_PASSWORD,  // SQL Server database password
    server: process.env.DB_SERVERhAWA11,  // SQL Server server address
    database: process.env.TRAININGDATA,  // SQL Server database name
    options: {
        encrypt: true,  // Use encryption for data transfer
        enableArithAbort: true  // Important for newer versions of MSSQL
    }
};

// Connect to MSSQL database
sql.connect(dbConfig).then(() => {
    console.log("Database Connected");
}).catch(err => {
    console.error("Database Connection Failed:", err);
});

// Middleware for managing sessions
app.use(session({
    secret: process.env.SESSION_SECRET,  // Secret for session management
    resave: false,  // Prevents resaving unchanged sessions
    saveUninitialized: true,  // Save uninitialized sessions
    cookie: {
        httpOnly: true,  // Prevents client-side script from accessing the cookie
        secure: process.env.NODE_ENV === 'production',  // Sets secure attribute for HTTPS
        sameSite: 'strict',  // Prevents cross-site request forgery
    }
}));

app.use(express.urlencoded({ extended: true }));  // Middleware for parsing URL-encoded data
app.use(express.static(path.join(__dirname, 'public')));  // Middleware for serving static files
app.use(bodyParser.json());  // Middleware for parsing JSON bodies

// Serve the homepage
app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, 'hompage.html'));  // Serve homepage HTML file
});

// Serve the internal course registration page
app.get('/internal-course-registration', (req, res) => {
    res.sendFile(path.join(__dirname, 'intcoursereg.html'));  // Serve internal course registration HTML file
});

// Serve the external course registration page
app.get('/external-course-registration', (req, res) => {
    res.sendFile(path.join(__dirname, 'extcoursereg.html'));  // Serve external course registration HTML file
});

// Serve the delegate registration page
app.get('/delegate-registration', (req, res) => {
    res.sendFile(path.join(__dirname, 'delegateReg.html'));  // Serve delegate registration HTML file
});

// Delegate registration form handler
app.post('/submit-your-form-handler', async (req, res) => {
    // Placeholder for form processing logic
    res.send('Delegate Registration submitted successfully');  // Send response on successful submission
});

// Internal and external course registration form handler
app.post('/action_page.php', async (req, res) => {
    // Placeholder for form processing logic
    res.send('Course Registration submitted successfully');  // Send response on successful submission
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);  // Start the server and log the port
});
